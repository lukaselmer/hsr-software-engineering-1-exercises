package u16_coffe_shop;

/**
 * @author Lukas Elmer
 * @version 1.0
 * @created 01-Dez-2010 14:11:20
 */
public interface Coffee {

	public long getCost();

	public String getDescription();

}